#include <iostream>
#include <string>
#include "StackType.h"

using namespace std;

// Function to check if a string of parentheses is balanced
bool isBalanced(string str) {
    StackType<char> stack;
    for (char ch : str) {
        if (ch == '(') {
            stack.Push(ch);
        } else if (ch == ')') {
            if (stack.IsEmpty()) {
                return false; // Unmatched closing parenthesis
            }
            stack.Pop();
        }
    }
    return stack.IsEmpty(); // Balanced if stack is empty at the end
}

// Function to print the stack (non-destructive)
template <typename T>
void PrintStack(StackType<T>& stack) {
    StackType<T> tempStack;
    while (!stack.IsEmpty()) {
        T top = stack.Top();
        cout << top << " ";
        tempStack.Push(top);
        stack.Pop();
    }
    cout << endl;
    while (!tempStack.IsEmpty()) {
        stack.Push(tempStack.Top());
        tempStack.Pop();
    }
}

int main() {
    // Create a stack of integers
    StackType<int> intStack;

    // Check if the stack is empty
    if (intStack.IsEmpty())
        cout << "Stack is Empty" << endl;

    // Push four items
    intStack.Push(5);
    intStack.Push(7);
    intStack.Push(4);
    intStack.Push(2);

    // Check if the stack is empty
    if (!intStack.IsEmpty())
        cout << "Stack is not Empty" << endl;

    // Check if the stack is full
    if (!intStack.IsFull())
        cout << "Stack is not full" << endl;

    // Print the values in the stack
    cout << "Stack values: ";
    PrintStack(intStack);

    // Push another item
    intStack.Push(3);

    // Print the values in the stack
    cout << "Stack values after pushing 3: ";
    PrintStack(intStack);

    // Check if the stack is full
    if (intStack.IsFull())
        cout << "Stack is full" << endl;

    // Pop two items
    intStack.Pop();
    intStack.Pop();

    // Print top item
    cout << "Top item after popping two items: " << intStack.Top() << endl;

    // Test balanced parentheses
    string testStrings[] = {"()", "(())()(()())()", "(())()((()", "(())))((()"};
    for (string str : testStrings) {
        cout << str << " is " << (isBalanced(str) ? "Balanced" : "Not balanced") << endl;
    }

    return 0;
}

// Include the template definitions
#include "StackType.cpp"
template class StackType<int>;
template class StackType<char>;
